import os
from datetime import date

import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Director, Actor, Movie
from django.db.models import Q, Count, Sum, Avg


def get_directors(search_name=None, search_nationality=None):
    global query

    if not search_name and not search_nationality:
        return ''

    if search_name and not search_nationality:
        query = Q(full_name__icontains=search_name)

    elif not search_name and search_nationality:
        query = Q(nationality__icontains=search_nationality)

    elif search_name and search_nationality:
        query = Q(full_name__icontains=search_name) & Q(nationality__icontains=search_nationality)

    directors = Director.objects.filter(query)

    if not directors.exists():
        return ''

    result = []
    for director in directors.order_by('full_name'):
        result.append(f"Director: {director.full_name}, "
                      f"nationality: {director.nationality}, "
                      f"experience: {director.years_of_experience}")

    return '\n'.join(result)


def get_top_director():
    director = Director.objects.get_directors_by_movies_count().first()

    return f"Top Director: {director.full_name}, movies: {director.number_of_movies}."


def get_top_actor():
    actor_with_most_movies = (Movie.objects
                              .values('starring_actor__id', 'starring_actor__full_name')
                              .annotate(movies_count=Count('id'))
                              .order_by('-movies_count', 'starring_actor__full_name')
                              .first())

    if not actor_with_most_movies or actor_with_most_movies['movies_count'] == 0:
        return ''

    actor_id = actor_with_most_movies['starring_actor__id']
    actor_full_name = actor_with_most_movies['starring_actor__full_name']

    all_movies = Movie.objects.filter(starring_actor_id=actor_id)
    if not all_movies.exists():
        return ''

    avg_rating = all_movies.aggregate(Avg('rating'))['rating__avg']

    movie_titles = ', '.join(all_movies.values_list('title', flat=True))

    return (f"Top Actor: {actor_full_name}, "
            f"starring in movies: {movie_titles}, "
            f"movies average rating: {avg_rating:.1f}")
