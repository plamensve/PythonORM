# from django.contrib import admin
# from main_app.models import RestaurantReview, FoodCriticRestaurantReview, RegularRestaurantReview
#
#
# # Register your models here.
# @admin.register(FoodCriticRestaurantReview)
# class FoodCriticRestaurantReviewAdmin(admin.ModelAdmin):
#     pass
#
#
# @admin.register(RegularRestaurantReview)
# class RegularRestaurantReviewAdmin(admin.ModelAdmin):
#     pass
