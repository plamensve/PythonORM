create function fn_count_employees_by_town(town_name character varying) returns integer
    language plpgsql
as
$$
        DECLARE
            town_count INT;
        BEGIN
            SELECT INTO town_count
                COUNT(*)
            FROM
                employees AS e
                JOIN addresses AS a ON e.address_id = a.address_id
                JOIN towns AS t ON a.town_id = t.town_id
            WHERE
                t.name = town_name;
            RETURN town_count;
        end;
    $$;

alter function fn_count_employees_by_town(varchar) owner to "postgres-user";

